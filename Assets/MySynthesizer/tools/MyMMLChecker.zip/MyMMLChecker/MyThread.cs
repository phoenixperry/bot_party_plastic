﻿using System;

namespace MySpace
{
    public class MyThread : IDisposable
    {
        private System.Threading.AutoResetEvent arEvent;
        private System.Threading.Thread thread;
        private volatile bool exit = false;
        private bool disposed = false;
        public MyThread()
        {
        }
        ~MyThread()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                this.Terminate(disposing);
                this.disposed = true;
            }
        }
        private void Terminate(bool disposing)
        {
            if (thread != null)
            {
                exit = true;
                if (disposing)
                {
                    arEvent.Set();
                    thread.Join();
                    arEvent.Close();
                }
                thread = null;
                arEvent = null;
            }
        }
        public void Raise()
        {
            arEvent.Set();
        }
        public void Start(Action action)
        {
            exit = false;
            arEvent = new System.Threading.AutoResetEvent(false);
            thread = new System.Threading.Thread(() =>
            {
                try
                {
                    while (!exit)
                    {
                        arEvent.WaitOne();
                        action();
                    }
                }
#if !DEBUG
                catch (Exception e)
                {
                    throw e;
                }
#endif
                finally
                {
                    exit = false;
                }
            });
            thread.Priority = System.Threading.ThreadPriority.AboveNormal;
            thread.Start();
        }
        public void Stop()
        {
            Terminate(true);
        }
    }
}
